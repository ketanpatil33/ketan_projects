import ProfileCard from "./ProfileCard"

function App() {
  return (
    <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
      <ProfileCard 
        name="Ketan Patil" 
        role="Web Developer"
        image="https://i.pravatar.cc/100"
        about="Passionate about coding and building cool web apps 🚀"
      />
    </div>
  )
}

export default App
