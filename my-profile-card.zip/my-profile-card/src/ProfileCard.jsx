function profileCard({name ,role,image,about}){
    return (
        <div style={{
            border: "2px solid #ccc",
      borderRadius: "12px",
      padding: "16px",
      width: "250px",
      textAlign: "center",
      boxShadow: "0 4px 8px rgba(0,0,0,0.1)"

        }}>
        <img 
        src={image} 
        alt={`${name}'s profile`} 
        style={{ width: "100px", height: "100px", borderRadius: "50%" }}
        />
        <h2>{name}</h2>
      <h4 style={{ color: "gray" }}>{role}</h4>
      <p>{about}</p>
    </div>
  )
}

export default profileCard;
